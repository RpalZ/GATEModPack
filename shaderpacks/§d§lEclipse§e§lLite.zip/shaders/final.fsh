#version 120

// Texture samplers
uniform sampler2D texture;       // The main texture
uniform sampler2D shadowMap;     // Shadow map texture
uniform mat4 shadowMatrix;       // Shadow transformation matrix (world space to light space)

// Varying variables passed from the vertex shader
varying vec2 texcoord;           // Texture coordinates for the fragment
varying vec4 fragPosition;       // World-space position for the fragment

// Function to calculate shadows from the shadow map
float getShadow(vec3 fragPos) {
    vec4 lightSpacePos = shadowMatrix * vec4(fragPos, 1.0); // Transform position to light space
    lightSpacePos.xyz /= lightSpacePos.w; // Normalize the position
    vec2 shadowCoord = lightSpacePos.xy * 0.5 + 0.5; // Convert to texture coordinates

    // Sample the shadow map
    float shadowDepth = texture2D(shadowMap, shadowCoord).r;

    // If the current depth is higher than the shadow map depth, it's in shadow
    return (lightSpacePos.z > shadowDepth + 0.005) ? 0.0 : 1.0; // 0.005 is a small bias to prevent shadow acne
}

void main() {
    // Simple base color from the texture
    vec3 baseColor = texture2D(texture, texcoord).rgb;
    
    // Calculate shadow intensity for this fragment
    float shadowFactor = getShadow(fragPosition.xyz);
    
    // Apply the shadow factor to darken the base color
    gl_FragColor = vec4(baseColor * shadowFactor, 1.0);
}
