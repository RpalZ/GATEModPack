/**
 * Converts depth texture coordinates to screen space.
 * Requires:
 * - mat4 gbufferProjectionInverse
 * - sampler2D depthtex0
 */

vec4 projDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);

vec3 toScreenSpace(vec2 p, float d) 
{
    vec3 p3 = vec3(p, d) * 2.0 - 1.0;
    vec4 fragPos = projDiag * p3.xyzz + gbufferProjectionInverse[3];

    return fragPos.xyz / fragPos.w;
}
