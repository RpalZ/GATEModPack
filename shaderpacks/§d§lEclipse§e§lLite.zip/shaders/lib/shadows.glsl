// Simple Low-End Shadow Shader for Intel Graphics

uniform sampler2D shadowMap;  // The shadow map texture
uniform mat4 shadowMatrix;    // The light's transformation matrix
uniform float bias;           // Bias to avoid shadow acne

varying vec4 fragPosition;    // World-space position of the fragment
varying vec2 texcoord;        // Texture coordinates for the fragment

float getShadow(vec3 fragPos) {
    // Transform the fragment position to light space
    vec4 lightSpacePos = shadowMatrix * vec4(fragPos, 1.0);
    
    // Normalize the position to get coordinates in [0, 1]
    lightSpacePos.xyz /= lightSpacePos.w;
    vec2 shadowCoord = lightSpacePos.xy * 0.5 + 0.5;

    // Sample the depth from the shadow map
    float shadowDepth = texture2D(shadowMap, shadowCoord).r;

    // Return shadow intensity based on depth comparison
    // If the current depth is higher than the sampled depth, it's in shadow
    return (lightSpacePos.z - bias > shadowDepth) ? 0.0 : 1.0;
}

void main() {
    // Calculate shadow factor for the current fragment
    float shadowFactor = getShadow(fragPosition.xyz);
    
    // Use a simple base color (assuming you are using textures)
    vec3 baseColor = texture2D(sampler2D(0), texcoord).rgb; // Assuming texture at texture unit 0
    
    // Apply the shadow factor to darken the color if in shadow
    gl_FragColor = vec4(baseColor * shadowFactor, 1.0); // Apply shadow
}
