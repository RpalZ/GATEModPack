float getSkyDot(vec2 coord, float depth)
{
    vec3 pos = normalize(toScreenSpace(coord, depth));
    vec3 normUp = normalize(upPosition);
    
    return dot(pos, normUp);
}

vec3 getSkyColor(vec2 coord, float depth, vec3 zenithRGB, vec3 horizonRGB, vec3 voidRGB)
{
    float dot = getSkyDot(coord, depth);
    
    if (dot >= 0)
    {
        return mix(horizonRGB, zenithRGB, pow(dot, 2));
    }
    else
    {
        return mix(horizonRGB, voidRGB, clamp(-dot, 0, 1));
    }
}

vec3 getSky(vec2 coord, float depth)
{
    vec3 day = getSkyColor(coord, depth, vec3(0.2, 0.5, 1.0), vec3(0.6, 0.8, 1.0), vec3(0.0, 0.0, 0.1));
    vec3 night = getSkyColor(coord, depth, vec3(0.05, 0.1, 0.3), vec3(0.1, 0.15, 0.3), vec3(0.0, 0.0, 0.05));
    
    return mix(day, night, getTimeCycleMixer());
}
