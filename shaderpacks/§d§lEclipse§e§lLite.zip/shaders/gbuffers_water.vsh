#version 120

attribute vec4 mc_Entity;

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform int frameCounter;

varying vec4 color;
varying vec2 lmcoord;
varying vec2 texcoord;

void main() {
    vec4 pos = gl_Vertex;

    if (mc_Entity.x == 8.0 || mc_Entity.x == 9.0) {
        float waveSpeed = float(frameCounter) * 0.005; // slow
        float waveFreq = 0.2;
        float wave = sin((pos.x + pos.z) * waveFreq + waveSpeed) * 0.03;
        pos.y += wave;
    }

    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * pos;

    color = gl_Color;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    texcoord = gl_MultiTexCoord0.st;
}
