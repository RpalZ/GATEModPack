#version 120

uniform sampler2D texture;
uniform float time;

varying vec2 texcoord;

void main() {
    // Clamp texture coords tightly, remove border bleeding
    vec2 safeUV = clamp(texcoord, 0.01, 0.99);

    vec4 texColor = texture2D(texture, safeUV);

    if (texColor.a < 0.05) discard;

    // Increase the blue tint — more Minecraft ocean vibes
    texColor.rgb = mix(texColor.rgb, vec3(0.15, 0.35, 1.0), 0.25); // deeper blue

    texColor.a *= 0.88;

    gl_FragColor = texColor;
}
